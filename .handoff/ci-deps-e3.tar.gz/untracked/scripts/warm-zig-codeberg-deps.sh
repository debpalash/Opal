#!/bin/sh
# Warm exact upstream Zig packages through official archives when Codeberg's
# Git smart protocol is unavailable. Hashes remain those pinned by DVUI/SDL.
set -eu
warm_dir=$(mktemp -d)
trap 'rm -rf "$warm_dir"' EXIT HUP INT TERM
warm_package() {
    archive_url=$1
    expected_hash=$2
    archive_file="$warm_dir/package.tar.gz"
    curl --fail --silent --show-error --location --proto '=https' --proto-redir '=https' \
        --connect-timeout 10 --max-time 60 --retry 2 --retry-delay 2 \
        --retry-max-time 150 "$archive_url" --output "$archive_file"
    actual_hash=$(zig fetch "$archive_file")
    if [ "$actual_hash" != "$expected_hash" ]; then
        printf '%s\n' "Pinned package mismatch: expected $expected_hash, received $actual_hash" >&2
        exit 1
    fi
    printf '%s\n' "Verified pinned package $actual_hash"
}
warm_package \
    'https://codeberg.org/brodo/xcode-frameworks/archive/5409ad866587de1b5670c2e94dfe46a95230d3e2.tar.gz' \
    'xcode_frameworks-0.0.0-VCh8grYYXAfTa0GCiNcepI3xiZ6cvS3-_TwbJw_4MJuG'
warm_package \
    'https://codeberg.org/david-vanderson/SDL/archive/941937d261e1cbb89bb8905f1d6f66b4f21ff312.tar.gz' \
    'sdl-0.4.0+3.4.2-SDL--iEpAgD_8zjY9OaeW6F21dX_Fi1zvuZvs5xAWfLt'
