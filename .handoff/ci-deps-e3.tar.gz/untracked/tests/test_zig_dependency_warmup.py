"""Hermetic production-script contracts; no remote downloads or package changes."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PINS = {
    "https://codeberg.org/brodo/xcode-frameworks/archive/5409ad866587de1b5670c2e94dfe46a95230d3e2.tar.gz": "xcode_frameworks-0.0.0-VCh8grYYXAfTa0GCiNcepI3xiZ6cvS3-_TwbJw_4MJuG",
    "https://codeberg.org/david-vanderson/SDL/archive/941937d261e1cbb89bb8905f1d6f66b4f21ff312.tar.gz": "sdl-0.4.0+3.4.2-SDL--iEpAgD_8zjY9OaeW6F21dX_Fi1zvuZvs5xAWfLt",
}


@unittest.skipUnless(shutil.which("sh"), "POSIX build script requires sh")
class Warmup(unittest.TestCase):
    def run_fixture(self, mode="success"):
        with tempfile.TemporaryDirectory(prefix="opal-pinned-deps-") as tmp:
            directory = Path(tmp)
            fake = directory / "commands"
            fake.mkdir()
            log = directory / "calls.jsonl"
            executable = fake / "fake.py"
            executable.write_text('''#!/usr/bin/env python3
import json, os, pathlib, sys
name=pathlib.Path(sys.argv[0]).name
args=sys.argv[1:]
with open(os.environ['CALL_LOG'],'a',encoding='utf-8') as output:
    output.write(json.dumps([name,args])+'\\n')
if name=='curl':
    if os.environ['MODE']=='download_failure': sys.exit(22)
    target=args[args.index('--output')+1]
    url=next(arg for arg in args if arg.startswith('https://'))
    pathlib.Path(target).write_text(url,encoding='utf-8')
else:
    assert args[0]=='fetch' and len(args)==2
    url=pathlib.Path(args[1]).read_text(encoding='utf-8')
    pins=json.loads(os.environ['PINS'])
    print('wrong-package-hash' if os.environ['MODE']=='hash_failure' else pins[url])
''', encoding="utf-8")
            executable.chmod(0o755)
            for name in ("curl", "zig"):
                shutil.copyfile(executable, fake / name)
                (fake / name).chmod(0o755)
            env = os.environ.copy()
            env.update(PATH=str(fake) + os.pathsep + env["PATH"], CALL_LOG=str(log), MODE=mode, PINS=json.dumps(PINS))
            result = subprocess.run(["sh", str(ROOT / "scripts/warm-zig-codeberg-deps.sh")], env=env, capture_output=True, text=True, timeout=10)
            calls = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
            archives = [Path(args[args.index("--output") + 1]) for name, args in calls if name == "curl"]
            self.assertTrue(all(not path.exists() for path in archives), "temporary archives must be removed even on failure")
            return result, calls

    def test_exact_pins_limits_and_success(self):
        result, calls = self.run_fixture()
        self.assertEqual(result.returncode, 0, result.stderr)
        downloads = [args for name, args in calls if name == "curl"]
        self.assertEqual([next(arg for arg in args if arg.startswith("https://")) for args in downloads], list(PINS))
        for args in downloads:
            for flag, value in (("--connect-timeout", "10"), ("--max-time", "60"), ("--retry", "2"), ("--retry-max-time", "150"), ("--proto", "=https"), ("--proto-redir", "=https")):
                self.assertEqual(args[args.index(flag) + 1], value)
        for expected in PINS.values():
            self.assertIn(expected, result.stdout)

    def test_hash_mismatch_stops_before_next_package(self):
        result, calls = self.run_fixture("hash_failure")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Pinned package mismatch", result.stderr)
        self.assertEqual([name for name, _ in calls], ["curl", "zig"])

    def test_download_failure_stops_without_zig(self):
        result, calls = self.run_fixture("download_failure")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual([name for name, _ in calls], ["curl"])

    def test_linux_and_docker_builds_warm_same_script(self):
        workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
        self.assertEqual(workflow.count("run: sh scripts/warm-zig-codeberg-deps.sh"), 2)
        self.assertIn("if: runner.os != 'Windows'", workflow)
        docker = (ROOT / "Dockerfile").read_text(encoding="utf-8")
        self.assertLess(docker.index("sh scripts/warm-zig-codeberg-deps.sh"), docker.index("zig build -Dheadless=true"))
        compat = (ROOT / "packaging/linux-compat/Dockerfile").read_text(encoding="utf-8")
        self.assertLess(compat.index("RUN sh scripts/warm-zig-codeberg-deps.sh"), compat.index("RUN --mount=type=secret"))


if __name__ == "__main__":
    unittest.main()
